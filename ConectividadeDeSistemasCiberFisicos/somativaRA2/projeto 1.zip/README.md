# Projeto 1: Monitoramento de Temperatura em Ambientes IoT
> Ordem de inicialização do projeto:

 - server.py
 - sensor_client.py

> Para consultar os dados:

 - control_panel.py
